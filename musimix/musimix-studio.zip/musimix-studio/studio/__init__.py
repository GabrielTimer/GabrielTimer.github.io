"""MusiMix Studio : prépare les morceaux (pistes séparées, paroles synchronisées, accords)."""
