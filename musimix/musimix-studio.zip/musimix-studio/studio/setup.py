"""MusiMix Studio — fin d'installation : ffmpeg + téléchargement des modèles (une seule fois)."""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def step(msg: str) -> None:
    print(f"\n▶ {msg}", flush=True)


def main() -> int:
    ok = True
    step("ffmpeg (lecture et conversion des fichiers audio)")
    try:
        import imageio_ffmpeg  # type: ignore
        src = Path(imageio_ffmpeg.get_ffmpeg_exe())
        dst = Path(sys.executable).parent / ("ffmpeg.exe" if sys.platform == "win32" else "ffmpeg")
        if not dst.exists():
            shutil.copy(src, dst)
        print(f"  ffmpeg prêt : {dst}")
    except Exception as exc:  # noqa: BLE001
        ok = False
        print(f"  ✗ ffmpeg : {exc}")

    step("Carte graphique")
    from studio import pipeline as P
    dev = P.device()
    print(f"  Calcul sur : {'GPU ' + (P.gpu_name() or '') if dev == 'cuda' else 'processeur (plus lent mais ça marche)'}")

    from studio.server import MODELS
    step("Modèle de séparation de la voix (BS-Roformer, ~650 Mo)")
    try:
        from audio_separator.separator import Separator  # type: ignore
        sep = Separator(output_dir=str(MODELS), model_file_dir=str(MODELS))
        sep.load_model(model_filename=P.VOCAL_MODEL)
        print("  ✓")
    except Exception as exc:  # noqa: BLE001
        print(f"  ✗ {exc}\n  (la voix sera séparée par Demucs à la place)")

    step("Modèles de séparation des instruments (Demucs)")
    try:
        from demucs.pretrained import get_model  # type: ignore
        for name in ("htdemucs_6s", "htdemucs"):
            get_model(name)
            print(f"  ✓ {name}")
    except Exception as exc:  # noqa: BLE001
        ok = False
        print(f"  ✗ {exc}")

    step(f"Modèle de reconnaissance des paroles (Whisper {P.WHISPER_MODEL}, ~1,5 Go)")
    try:
        import whisper  # type: ignore
        whisper.load_model(P.WHISPER_MODEL, device="cpu")
        print("  ✓")
    except Exception as exc:  # noqa: BLE001
        ok = False
        print(f"  ✗ {exc}")

    print("\n" + ("✅ Installation terminée." if ok else "⚠ Installation terminée avec des avertissements (voir ci-dessus)."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
