"""MusiMix Studio — analyse musicale : tempo, temps, mesures, tonalité, accords.

Uniquement numpy + scipy (pas de dépendance lourde) :
  • chroma « blanchi » (on retire l'enveloppe spectrale → restent les notes),
  • suivi de pulsation par programmation dynamique (Ellis 2007),
  • accords : gabarits par temps + Viterbi (changements favorisés sur les temps forts),
  • basse : chroma grave séparé (piste basse si disponible) → fondamentale et accords « slash ».
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass

import numpy as np
from scipy.ndimage import uniform_filter1d

SR = 22050
NOTES_SHARP = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTES_FLAT = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]
DEFAULT_SPELL = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]
FLAT_MAJOR = {5, 10, 3, 8, 1}
FLAT_MINOR = {2, 7, 0, 5, 10, 3}


def ffmpeg_exe() -> str:
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg  # type: ignore
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("ffmpeg introuvable") from exc


def load_mono(path, sr: int = SR) -> np.ndarray:
    cmd = [ffmpeg_exe(), "-v", "error", "-i", str(path), "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    raw = subprocess.run(cmd, check=True, capture_output=True).stdout
    return np.frombuffer(raw, dtype=np.float32).copy()


def mix(signals: list[np.ndarray]) -> np.ndarray:
    n = max(len(s) for s in signals)
    out = np.zeros(n, dtype=np.float32)
    for s in signals:
        out[: len(s)] += s
    return out


# ───────────────────────────────────────────────────────── spectre ──
def stft_mag(y: np.ndarray, n_fft: int, hop: int) -> np.ndarray:
    if len(y) < n_fft:
        y = np.pad(y, (0, n_fft - len(y)))
    y = np.pad(y, (n_fft // 2, n_fft // 2))
    win = np.hanning(n_fft).astype(np.float32)
    n_frames = 1 + (len(y) - n_fft) // hop
    out = np.empty((n_frames, n_fft // 2 + 1), dtype=np.float32)
    block = 256
    for b in range(0, n_frames, block):
        idx = np.arange(b, min(b + block, n_frames))[:, None] * hop + np.arange(n_fft)[None, :]
        out[b: b + len(idx)] = np.abs(np.fft.rfft(y[idx] * win, axis=1))
    return out


def chroma_matrix(n_fft: int, sr: int, fmin: float, fmax: float) -> np.ndarray:
    freqs = np.fft.rfftfreq(n_fft, 1 / sr)
    m = np.zeros((len(freqs), 12), dtype=np.float32)
    ok = (freqs >= fmin) & (freqs <= fmax)
    midi = 69 + 12 * np.log2(np.maximum(freqs[ok], 1e-6) / 440.0)
    nearest = np.round(midi)
    weight = np.cos(np.clip(midi - nearest, -0.5, 0.5) * np.pi) ** 2
    m[np.where(ok)[0], (nearest.astype(int) % 12)] = weight
    return m


def whiten(logmag: np.ndarray, width: int = 40) -> np.ndarray:
    return np.maximum(0.0, logmag - uniform_filter1d(logmag, width, axis=1))


def onset_envelope(y: np.ndarray, sr: int = SR, hop: int = 512) -> np.ndarray:
    mag = stft_mag(y, 2048, hop)
    logm = np.log1p(100 * mag)
    flux = np.maximum(0, np.diff(logm, axis=0)).sum(axis=1)
    flux = np.concatenate([[0], flux])
    k = max(1, int(0.5 * sr / hop))
    local = np.convolve(flux, np.ones(k) / k, mode="same")
    env = np.maximum(0, flux - local)
    return env / (env.std() + 1e-9)


# ──────────────────────────────────────────────────────── tempo ──
def estimate_tempo(env: np.ndarray, sr: int = SR, hop: int = 512) -> float:
    fps = sr / hop
    e = env - env.mean()
    n = len(e)
    ac = np.fft.irfft(np.abs(np.fft.rfft(e, 2 * n)) ** 2)[:n]
    bpms = np.arange(55, 200, 0.25)
    lags = fps * 60 / bpms
    vals = np.interp(lags, np.arange(n), ac)
    # renfort des multiples (le tempo réel a aussi des pics à 2× et 1/2×)
    vals2 = np.interp(lags * 2, np.arange(n), ac)
    prior = np.exp(-0.5 * (np.log2(bpms / 105.0) / 0.8) ** 2)
    score = (vals + 0.5 * vals2) * prior
    return float(bpms[np.argmax(score)])


def track_beats(env: np.ndarray, bpm: float, sr: int = SR, hop: int = 512, tightness: float = 120.0) -> np.ndarray:
    fps = sr / hop
    period = fps * 60 / bpm
    n = len(env)
    score = env.astype(np.float64).copy()
    back = np.full(n, -1)
    lo, hi = int(round(period / 2)), int(round(2 * period))
    if n <= hi + 2:
        return np.array([])
    offsets = np.arange(-hi, -lo + 1)
    penalty = -tightness * np.log(-offsets / period) ** 2
    for t in range(hi, n):
        cand = score[t + offsets] + penalty
        j = int(np.argmax(cand))
        score[t] = env[t] + cand[j]
        back[t] = t + offsets[j]
    t = int(n - hi + np.argmax(score[n - hi:]))
    beats = []
    while t >= 0:
        beats.append(t)
        t = back[t]
    beats = np.array(beats[::-1], dtype=np.float64) / fps
    # on retire les temps avant le début réel de la musique
    return beats


@dataclass
class Features:
    times: np.ndarray
    chroma: np.ndarray
    bass: np.ndarray
    rms: np.ndarray
    beats: np.ndarray
    bpm: float
    onset: np.ndarray
    bass_separated: bool = False


def extract_features(y_harm: np.ndarray, y_bass: np.ndarray | None, y_rhythm: np.ndarray) -> Features:
    n_fft, hop = 8192, 1024
    mag = whiten(np.log1p(30 * stft_mag(y_harm, n_fft, hop)))
    chroma = mag @ chroma_matrix(n_fft, SR, 65.0, 1000.0)
    if y_bass is not None:
        bmag = whiten(np.log1p(30 * stft_mag(y_bass, n_fft, hop)), 20)
    else:
        bmag = mag
    bass = bmag @ chroma_matrix(n_fft, SR, 36.0, 250.0)
    n = min(len(chroma), len(bass))
    chroma, bass = chroma[:n], bass[:n]
    frames = np.arange(n) * hop
    rms = np.array([np.sqrt(np.mean(y_harm[f: f + hop] ** 2)) if f < len(y_harm) else 0.0 for f in frames])
    times = frames / SR
    env = onset_envelope(y_rhythm)
    bpm = estimate_tempo(env)
    beats = track_beats(env, bpm)
    # premiers temps : seulement quand la musique a commencé
    energy = np.convolve(np.abs(y_rhythm), np.ones(2048) / 2048, mode="same")[::512] if len(y_rhythm) else np.array([])
    if len(beats) and len(energy):
        thr = 0.08 * np.percentile(energy, 95)
        start = np.argmax(energy > thr) * 512 / SR if (energy > thr).any() else 0
        beats = beats[beats >= start - 0.15]
    return Features(times, chroma, bass, rms, beats, bpm, env, y_bass is not None)


# ─────────────────────────────────────────────────────── tonalité ──
MAJOR_PROFILE = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
MINOR_PROFILE = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])


def estimate_key(chroma: np.ndarray) -> tuple[int, bool]:
    prof = chroma.mean(axis=0)
    best, best_score = (0, True), -2.0
    for r in range(12):
        for major, p in ((True, MAJOR_PROFILE), (False, MINOR_PROFILE)):
            s = np.corrcoef(prof, np.roll(p, r))[0, 1]
            if s > best_score:
                best, best_score = (r, major), s
    return best


def spelling(root: int, major: bool) -> list[str]:
    if major and root == 6:
        return NOTES_SHARP
    flats = (root in FLAT_MAJOR) if major else (root in FLAT_MINOR)
    return NOTES_FLAT if flats else NOTES_SHARP


def key_name(root: int, major: bool) -> str:
    return spelling(root, major)[root] + ("" if major else "m")


# ──────────────────────────────────────────────────────── accords ──
QUALITIES = {
    "maj": ([0, 4, 7], "", 1.00),
    "min": ([0, 3, 7], "m", 1.00),
    "7": ([0, 4, 7, 10], "7", 0.975),
    "maj7": ([0, 4, 7, 11], "maj7", 0.975),
    "m7": ([0, 3, 7, 10], "m7", 0.975),
    "sus4": ([0, 5, 7], "sus4", 0.95),
    "sus2": ([0, 2, 7], "sus2", 0.94),
    "dim": ([0, 3, 6], "dim", 0.94),
    "m7b5": ([0, 3, 6, 10], "m7b5", 0.95),
}
VOCABS = {
    "simple": ["maj", "min"],
    "pop": ["maj", "min", "7", "sus4"],
    "full": ["maj", "min", "7", "maj7", "m7", "sus4", "dim", "m7b5"],
}


def diatonic(root: int, major: bool) -> set[tuple[int, str]]:
    if major:
        steps = [(0, "maj"), (2, "min"), (4, "min"), (5, "maj"), (7, "maj"), (9, "min"),
                 (0, "maj7"), (2, "m7"), (4, "m7"), (5, "maj7"), (7, "7"), (9, "m7"), (11, "m7b5"), (11, "dim"),
                 (7, "sus4"), (2, "sus4"), (9, "sus4")]
    else:
        steps = [(0, "min"), (3, "maj"), (5, "min"), (7, "min"), (7, "maj"), (8, "maj"), (10, "maj"),
                 (0, "m7"), (3, "maj7"), (5, "m7"), (7, "7"), (8, "maj7"), (2, "m7b5"), (2, "dim"), (10, "7")]
    return {((root + i) % 12, q) for i, q in steps}


def recognize_chords(f: Features, vocab: str = "full", key: tuple[int, bool] | None = None,
                     change_penalty: float = 0.9) -> tuple[list[dict], tuple[int, bool], np.ndarray]:
    """Accords calés sur les temps. Retourne (accords [{name,s,e}], tonalité, temps forts)."""
    k_root, k_major = key or estimate_key(f.chroma)
    names = spelling(k_root, k_major)
    dia = diatonic(k_root, k_major)
    end_t = float(f.times[-1] + 0.05) if len(f.times) else 0.0
    beats = f.beats[(f.beats > 0.05) & (f.beats < end_t)] if len(f.beats) else np.array([])
    if len(beats) < 4:
        beats = np.arange(0.5, end_t, 60 / max(f.bpm, 60))
    edges = np.unique(np.concatenate([[0.0], beats, [end_t]]))
    seg_idx = np.searchsorted(edges, f.times, side="right") - 1
    n_seg = len(edges) - 1
    C = np.zeros((n_seg, 12)); B = np.zeros((n_seg, 12)); E = np.zeros(n_seg)
    for s in range(n_seg):
        m = seg_idx == s
        if m.any():
            C[s] = np.median(f.chroma[m], axis=0)
            B[s] = np.median(f.bass[m], axis=0)
            E[s] = f.rms[m].mean()
    C = C - C.min(axis=1, keepdims=True)
    Cn = C / (np.linalg.norm(C, axis=1, keepdims=True) + 1e-9)
    Bn = B / (B.max(axis=1, keepdims=True) + 1e-9)

    labels: list[tuple[int, str]] = []
    templates = []
    for q in VOCABS[vocab]:
        ivs, _, w = QUALITIES[q]
        for r in range(12):
            t = np.zeros(12)
            for j, iv in enumerate(ivs):
                t[(r + iv) % 12] = 1.0 if j < 3 else 0.75
            templates.append(w * t / np.linalg.norm(t))
            labels.append((r, q))
    T = np.array(templates)
    roots = np.array([r for r, _ in labels])
    bonus = np.array([0.035 if lab in dia else 0.0 for lab in labels])
    score = Cn @ T.T + 0.14 * Bn[:, roots] + bonus[None, :]

    pos = E[E > 0]
    silent = E < 0.06 * np.percentile(pos, 90) if len(pos) else np.ones(n_seg, bool)
    K = len(labels)
    emit = np.concatenate([score * 12, np.where(silent, 8.0, 1.5)[:, None]], axis=1)

    def viterbi(pen: np.ndarray) -> np.ndarray:
        dp = emit[0].copy()
        back = np.zeros((n_seg, K + 1), dtype=np.int32)
        for s in range(1, n_seg):
            best_prev = int(np.argmax(dp))
            move = dp[best_prev] - pen[s]
            choose = move > dp
            back[s] = np.where(choose, best_prev, np.arange(K + 1))
            dp = np.where(choose, move, dp) + emit[s]
        path = np.zeros(n_seg, dtype=np.int32)
        path[-1] = int(np.argmax(dp))
        for s in range(n_seg - 1, 0, -1):
            path[s - 1] = back[s, path[s]]
        return path

    base = change_penalty * 1.2
    path = viterbi(np.full(n_seg, base))
    # où tombent les premiers temps ? là où les accords changent le plus (+ attaques de basse)
    changes = np.where(np.diff(path) != 0)[0] + 1
    seg_edges_beats = edges[:-1]
    phase = 0
    if len(changes) > 6:
        votes = np.bincount(changes % 4, minlength=4).astype(float)
        phase = int(np.argmax(votes))
        pen = np.full(n_seg, base * 1.8)
        idx = np.arange(n_seg)
        pen[idx % 2 == phase % 2] = base * 1.1
        pen[idx % 4 == phase] = base * 0.5
        path = viterbi(pen)
    downbeats = seg_edges_beats[np.arange(n_seg) % 4 == phase]
    downbeats = downbeats[downbeats > 0.01] if len(downbeats) else downbeats

    chords: list[dict] = []
    for s, k in enumerate(path):
        if k == K:
            name = "N"
        else:
            r, q = labels[k]
            name = names[r] + QUALITIES[q][1]
            # accord « slash » : basse nette sur la tierce ou la quinte
            if f.bass_separated and Bn[s].max() > 0:
                bpc = int(np.argmax(Bn[s]))
                ivs = QUALITIES[q][0]
                if bpc != r and (bpc - r) % 12 in ivs[1:3] and Bn[s, bpc] > 1.6 * Bn[s, r] and Bn[s, bpc] > 0.5:
                    name += "/" + names[bpc]
        st, en = float(edges[s]), float(edges[s + 1])
        if chords and chords[-1]["name"] == name:
            chords[-1]["e"] = round(en, 3)
        else:
            chords.append({"name": name, "s": round(st, 3), "e": round(en, 3)})
    # nettoyage : accords d'un temps entourés du même accord, slash isolés
    min_len = 0.75 * 60 / max(f.bpm, 40)
    cleaned: list[dict] = []
    for c in chords:
        if cleaned and (c["e"] - c["s"]) < min_len:
            cleaned[-1]["e"] = c["e"]
        elif cleaned and cleaned[-1]["name"] == c["name"]:
            cleaned[-1]["e"] = c["e"]
        else:
            cleaned.append(dict(c))
    merged: list[dict] = []
    for c in cleaned:
        if merged and merged[-1]["name"].split("/")[0] == c["name"].split("/")[0] and (c["e"] - c["s"]) < 2 * min_len:
            merged[-1]["e"] = c["e"]
        else:
            merged.append(c)
    merged = [c for c in merged if c["name"] != "N"]
    return merged, (k_root, k_major), downbeats


def peaks(y: np.ndarray, n: int = 900) -> list[float]:
    if not len(y):
        return []
    step = max(1, len(y) // n)
    m = np.abs(y[: step * n]).reshape(-1, step)
    v = np.sqrt((m ** 2).mean(axis=1))
    v = v / (np.percentile(v, 99) + 1e-9)
    return [round(float(min(1.0, x)), 3) for x in v]


def analyse(y_harm: np.ndarray, y_bass: np.ndarray | None, y_rhythm: np.ndarray, y_mix: np.ndarray,
            vocab: str = "full", key_hint: str | None = None) -> dict:
    f = extract_features(y_harm, y_bass, y_rhythm)
    key = None
    if key_hint:
        k = parse_key(key_hint)
        if k:
            key = k
    chords, k1, downs = recognize_chords(f, vocab, key)
    if key is None:
        # 2e passe : la tonalité qui explique le mieux les accords trouvés
        k2 = key_from_chords(chords)
        if k2 and k2 != k1:
            chords, k1, downs = recognize_chords(f, vocab, k2)
    key = k1
    return {
        "bpm": round(f.bpm, 1),
        "beats": [round(float(b), 3) for b in f.beats],
        "downbeats": [round(float(b), 3) for b in downs],
        "key": key_name(*key),
        "key_pc": key[0], "key_major": key[1],
        "chords": chords,
        "peaks": peaks(y_mix),
        "duration": round(len(y_mix) / SR, 2),
    }


def key_from_chords(chords: list[dict]) -> tuple[int, bool] | None:
    rev = {n: i for i, n in enumerate(NOTES_SHARP)} | {n: i for i, n in enumerate(NOTES_FLAT)}
    w = {}
    for c in chords:
        name = c["name"].split("/")[0]
        root = name[:2] if len(name) > 1 and name[1] in "#b" else name[:1]
        q = name[len(root):]
        qual = {"": "maj", "m": "min", "7": "7", "maj7": "maj7", "m7": "m7", "sus4": "sus4", "sus2": "sus2", "dim": "dim", "m7b5": "m7b5"}.get(q, "maj")
        if root in rev:
            w[(rev[root], qual)] = w.get((rev[root], qual), 0) + (c["e"] - c["s"])
    if not w:
        return None
    best, best_s = None, -1.0
    for r in range(12):
        for major in (True, False):
            d = diatonic(r, major)
            tonic = {(r, "maj"), (r, "maj7")} if major else {(r, "min"), (r, "m7")}
            sc = sum(v for k, v in w.items() if k in d) + 0.35 * sum(v for k, v in w.items() if k in tonic)
            if sc > best_s:
                best, best_s = (r, major), sc
    return best


def parse_key(s: str) -> tuple[int, bool] | None:
    import re
    m = re.match(r"^\s*([A-Ga-g])([#b♯♭]?)\s*(m(?!aj)|min|-)?", s or "")
    if not m:
        return None
    pc = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}[m.group(1).upper()]
    if m.group(2) in ("#", "♯"):
        pc += 1
    elif m.group(2) in ("b", "♭"):
        pc -= 1
    return pc % 12, not bool(m.group(3))
