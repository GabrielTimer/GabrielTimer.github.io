"""MusiMix Studio — chaîne de préparation d'un morceau.

audio ─► conversion ─► voix (BS-Roformer, moteur d'Ultimate Vocal Remover)
                    ─► instruments (Demucs 6 pistes) ─► paroles (LRCLIB + Whisper, mot à mot)
                    ─► accords, tempo, mesures ─► pack MusiMix (ZIP)
"""
from __future__ import annotations

import gc
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

import numpy as np

from . import analysis as A
from . import sheet as S

VOCAL_MODEL = os.environ.get("MUSIMIX_VOCAL_MODEL", "model_bs_roformer_ep_317_sdr_12.9755.ckpt")
WHISPER_MODEL = os.environ.get("MUSIMIX_WHISPER", "medium")
STEM_LABELS = {"vocals": "Voix", "drums": "Batterie", "bass": "Basse", "guitar": "Guitare", "piano": "Piano",
               "other": "Autres", "instrumental": "Instrumental", "mix": "Morceau"}

Progress = Callable[[str, float, str], None]


class Cancelled(Exception):
    pass


_DEVICE: str | None = None


def device() -> str:
    """GPU si la carte graphique répond vraiment (test d'un petit calcul), sinon processeur."""
    global _DEVICE
    if _DEVICE is None:
        _DEVICE = "cpu"
        if os.environ.get("MUSIMIX_CPU"):
            return _DEVICE
        try:
            import torch  # type: ignore
            if torch.cuda.is_available():
                x = torch.ones(8, device="cuda") * 2
                if float(x.sum()) == 16.0:
                    _DEVICE = "cuda"
        except Exception as exc:  # noqa: BLE001
            print(f"  (carte graphique inutilisable : {exc} — calcul sur le processeur)")
    return _DEVICE


def gpu_name() -> str | None:
    try:
        import torch  # type: ignore
        return torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception:  # noqa: BLE001
        return None


def free_gpu() -> None:
    gc.collect()
    try:
        import torch  # type: ignore
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:  # noqa: BLE001
        pass


def run_ffmpeg(args: list[str]) -> None:
    subprocess.run([A.ffmpeg_exe(), "-v", "error", "-y", *args], check=True,
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


# ─────────────────────────────────────────────────── séparation ──
def separate_vocals(wav: Path, out: Path, models_dir: Path, log) -> tuple[Path, Path] | None:
    """Voix / instrumental avec audio-separator (le moteur d'Ultimate Vocal Remover)."""
    try:
        from audio_separator.separator import Separator  # type: ignore
    except Exception as exc:  # noqa: BLE001
        log(f"audio-separator indisponible ({exc}) : Demucs fera la voix")
        return None
    out.mkdir(parents=True, exist_ok=True)
    try:
        sep = Separator(output_dir=str(out), output_format="WAV", model_file_dir=str(models_dir))
        sep.load_model(model_filename=VOCAL_MODEL)
        files = sep.separate(str(wav))
    except Exception as exc:  # noqa: BLE001
        log(f"Séparation de la voix (Roformer) impossible : {exc}")
        return None
    finally:
        free_gpu()
    paths = [Path(f) if Path(f).is_absolute() else out / f for f in files]
    voc = next((p for p in paths if re.search(r"\(vocals?\)", p.name, re.I)), None)
    ins = next((p for p in paths if re.search(r"\((instrumental|other|no.?vocals?)\)", p.name, re.I)), None)
    if not voc or not ins:
        return None
    return voc, ins


def run_demucs(src: Path, out: Path, model: str, progress: Callable[[float], None], log, two_stems: str | None = None) -> dict[str, Path]:
    cmd = [sys.executable, "-m", "demucs", "-n", model, "-o", str(out), "-d", device()]
    if two_stems:
        cmd += ["--two-stems", two_stems]
    cmd.append(str(src))
    log(" ".join(cmd[2:]))
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), encoding="utf-8", errors="replace")
    buf = ""
    tail: list[str] = []
    assert proc.stdout
    while True:
        ch = proc.stdout.read(1)
        if not ch:
            break
        if ch in "\r\n":
            m = re.search(r"(\d+)%\|", buf)
            if m:
                progress(int(m.group(1)) / 100)
            elif buf.strip():
                tail.append(buf.strip())
                tail = tail[-8:]
            buf = ""
        else:
            buf += ch
    if proc.wait() != 0:
        raise RuntimeError("Demucs a échoué : " + " / ".join(tail[-3:]))
    return {p.stem: p for p in out.rglob("*.wav")}


# ─────────────────────────────────────────────────────── paroles ──
def lrclib(artist: str, title: str, duration: float | None, log) -> dict | None:
    if not title:
        return None
    hdr = {"User-Agent": "MusiMix-Studio/1.0 (https://github.com/gabrieltimer)"}
    tries = []
    if artist:
        q = {"artist_name": artist, "track_name": title}
        if duration:
            q["duration"] = str(round(duration))
        tries.append("https://lrclib.net/api/get?" + urllib.parse.urlencode(q))
    tries.append("https://lrclib.net/api/search?" + urllib.parse.urlencode({"q": f"{artist} {title}".strip()}))
    for url in tries:
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=hdr), timeout=12) as r:
                data = json.load(r)
            if isinstance(data, list):
                good = [d for d in data if d.get("plainLyrics") or d.get("syncedLyrics")]
                if duration:
                    good.sort(key=lambda d: abs((d.get("duration") or 0) - duration))
                data = good[0] if good else None
                if data and duration and abs((data.get("duration") or duration) - duration) > 12:
                    data = None
            if data and (data.get("plainLyrics") or data.get("syncedLyrics")):
                log(f"LRCLIB : paroles trouvées ({'synchronisées' if data.get('syncedLyrics') else 'texte'})")
                return data
        except Exception as exc:  # noqa: BLE001
            log(f"LRCLIB : {exc}")
    return None


class Whisper:
    def __init__(self, name: str, log):
        import stable_whisper  # type: ignore
        dev = device()
        self.fp16 = dev == "cuda"
        log(f"Chargement de Whisper « {name} » ({dev})…")
        try:
            self.model = stable_whisper.load_model(name, device=dev)
        except RuntimeError as exc:
            if "out of memory" not in str(exc).lower() or name == "small":
                raise
            log("Mémoire graphique insuffisante : modèle « small »")
            free_gpu()
            self.model = stable_whisper.load_model("small", device=dev)

    def detect_language(self, vocals: Path) -> str | None:
        try:
            import whisper  # type: ignore
            y = A.load_mono(vocals, 16000)
            if not len(y):
                return None
            win = 16000 * 30
            # fenêtre de 30 s la plus chantée
            if len(y) > win:
                e = np.convolve(y ** 2, np.ones(16000), mode="valid")[::16000]
                k = max(0, min(int(np.argmax(np.convolve(e, np.ones(30), mode="valid"))), len(y) // 16000 - 30))
                y = y[k * 16000: k * 16000 + win]
            audio = whisper.pad_or_trim(y.astype(np.float32))
            mel = whisper.log_mel_spectrogram(audio, n_mels=self.model.dims.n_mels).to(self.model.device)
            _, probs = self.model.detect_language(mel)
            return max(probs, key=probs.get)
        except Exception:  # noqa: BLE001
            return None

    def words(self, vocals: Path, text: str | None, lang: str | None) -> list[tuple[str, float, float]]:
        if text:
            res = self.model.align(str(vocals), text, language=lang or "fr", fp16=self.fp16)
        else:
            res = self.model.transcribe(str(vocals), language=lang, fp16=self.fp16, vad=False, regroup=True,
                                        suppress_silence=True, word_timestamps=True)
        out = []
        for seg in res.segments:
            for w in seg.words or []:
                if w.word.strip():
                    out.append((w.word.strip(), float(w.start), float(w.end)))
        return out

    def close(self):
        del self.model
        free_gpu()


# ───────────────────────────────────────────────────── chaîne ──
def guess_title_artist(filename: str) -> tuple[str, str]:
    n = re.sub(r"\.[^.]+$", "", filename).replace("_", " ")
    n = re.sub(r"\s*[(\[](official.*?|lyrics?.*?|audio|video|clip.*?|hd|hq|\d{3,4}p)[)\]]", "", n, flags=re.I).strip()
    if " - " in n:
        a, t = n.split(" - ", 1)
        return t.strip(), a.strip()
    return n.strip(), ""


def safe(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).strip() or "morceau"


def prepare(src: Path, work: Path, out_zip_dir: Path, opts: dict, progress: Progress, log, models_dir: Path,
            cancelled: Callable[[], bool] = lambda: False) -> Path:
    """Prépare un morceau. opts: title, artist, lang, sheet, quality (best|fast|voice), whisper."""
    t_start = time.time()
    work.mkdir(parents=True, exist_ok=True)

    def check():
        if cancelled():
            raise Cancelled()

    title = (opts.get("title") or "").strip()
    artist = (opts.get("artist") or "").strip()
    if not title:
        title, a2 = guess_title_artist(src.name)
        artist = artist or a2
    quality = opts.get("quality") or "best"
    sheet_text = (opts.get("sheet") or "").strip()
    lang = (opts.get("lang") or "").strip() or None

    # 1. conversion
    progress("convert", 0.01, "Lecture du fichier…")
    wav = work / "mix.wav"
    run_ffmpeg(["-i", str(src), "-ac", "2", "-ar", "44100", str(wav)])
    duration = len(A.load_mono(wav, 8000)) / 8000.0
    check()

    # 2. séparation
    stems: dict[str, Path] = {}
    sep_desc = ""
    if quality in ("best", "voice"):
        progress("vocals", 0.04, "Séparation de la voix (modèle Roformer)…")
        res = separate_vocals(wav, work / "uvr", models_dir, log)
        if res:
            stems["vocals"], stems["instrumental"] = res
            sep_desc = "BS-Roformer"
        check()
    if quality == "voice" and not stems:
        progress("vocals", 0.1, "Séparation voix / instrumental (Demucs)…")
        r = run_demucs(wav, work / "demucs", "htdemucs", lambda p: progress("vocals", 0.1 + 0.35 * p, "Séparation voix / instrumental…"), log, two_stems="vocals")
        stems["vocals"], stems["instrumental"] = r["vocals"], r["no_vocals"]
        sep_desc = "Demucs"
    if quality in ("best", "fast"):
        model = "htdemucs_6s" if quality == "best" else "htdemucs"
        src_for_demucs = stems.get("instrumental", wav)
        base = 0.25 if stems else 0.05
        progress("instruments", base, "Séparation des instruments…")
        r = run_demucs(src_for_demucs, work / "demucs", model,
                       lambda p: progress("instruments", base + (0.5 - base) * p, "Séparation des instruments…"), log)
        for k in ("drums", "bass", "guitar", "piano", "other"):
            if k in r:
                stems[k] = r[k]
        if "vocals" not in stems and "vocals" in r:
            stems["vocals"] = r["vocals"]
        if quality == "best" and "instrumental" in stems:
            stems.pop("instrumental")  # les pistes détaillées le remplacent
        sep_desc = (sep_desc + " + " if sep_desc else "") + f"Demucs {model}"
    free_gpu()
    check()

    # 3. analyse musicale (accords, tempo) sur les instruments sans voix ni batterie
    progress("chords", 0.52, "Recherche des accords et du tempo…")
    sr = A.SR
    harm_keys = [k for k in ("guitar", "piano", "other", "bass") if k in stems]
    y_mix = A.load_mono(wav)
    if harm_keys:
        y_harm = A.mix([A.load_mono(stems[k]) for k in harm_keys])
    elif "instrumental" in stems:
        y_harm = A.load_mono(stems["instrumental"])
    else:
        y_harm = y_mix
    y_bass = A.load_mono(stems["bass"]) if "bass" in stems else None
    y_rhythm = A.mix([A.load_mono(stems[k]) for k in ("drums", "bass") if k in stems]) if ("drums" in stems) else (A.load_mono(stems["instrumental"]) if "instrumental" in stems else y_mix)
    sheet_lines: list[S.Line] = []
    meta: dict = {}
    if sheet_text:
        sheet_lines, meta = S.parse_sheet(sheet_text)
    capo = int(meta.get("capo") or opts.get("capo") or 0)
    key_hint = meta.get("key")
    if key_hint and capo:
        # la grille est écrite en « formes » (capo) : la tonalité réelle est plus haute
        key_hint = S.transpose_name(key_hint.rstrip("m"), capo, False) + ("m" if key_hint.endswith("m") else "")
    an = A.analyse(y_harm, y_bass, y_rhythm, y_mix, "full", key_hint)
    detected = an["chords"]
    key_out = an["key"]
    if capo:
        flats = an["key"] in ("F", "Bb", "Eb", "Ab", "Db", "Gb", "Dm", "Gm", "Cm", "Fm", "Bbm", "Ebm")
        detected = [{**c, "name": S.transpose_name(c["name"], -capo, flats)} for c in detected]
        if not meta.get("key"):
            key_out = S.transpose_name(an["key"].rstrip("m"), -capo, flats) + ("m" if an["key"].endswith("m") else "")
    log(f"Tempo ≈ {an['bpm']} BPM · tonalité ≈ {an['key']} · {len(detected)} accords")
    check()

    # 4. paroles
    progress("lyrics", 0.58, "Recherche des paroles…")
    lyrics_src = "aucune"
    hit = None
    if not any(l.kind == "lyric" for l in sheet_lines) and not opts.get("no_lrclib"):
        hit = lrclib(artist, title, duration, log)
        if hit:
            sheet_lines, _ = S.parse_sheet(hit.get("plainLyrics") or "\n".join(t for _, t in S.parse_lrc(hit.get("syncedLyrics"))))
            lyrics_src = "LRCLIB"
    elif sheet_lines:
        lyrics_src = "texte fourni"
    words_ok = False
    if "vocals" in stems and not opts.get("no_whisper"):
        try:
            wh = Whisper(opts.get("whisper") or WHISPER_MODEL, log)
            try:
                if not lang:
                    progress("lyrics", 0.6, "Détection de la langue…")
                    lang = wh.detect_language(stems["vocals"])
                    log(f"Langue détectée : {lang}")
                check()
                text = S.plain_lyrics(sheet_lines) if any(l.kind == "lyric" for l in sheet_lines) else None
                if text:
                    progress("lyrics", 0.64, "Synchronisation des paroles, mot à mot…")
                    aligned = wh.words(stems["vocals"], text, lang)
                    found = S.assign_times(sheet_lines, aligned)
                    total = sum(len(S.tokens(l.text)) for l in sheet_lines if l.kind == "lyric")
                    words_ok = found > 0.3 * max(1, total)
                    log(f"Alignement : {found}/{total} mots retrouvés")
                    lyrics_src += " · aligné mot à mot"
                else:
                    progress("transcribe", 0.64, "Transcription des paroles…")
                    aligned = wh.words(stems["vocals"], None, lang)
                    sheet_lines = S.lines_from_transcript(aligned)
                    words_ok = bool(sheet_lines)
                    lyrics_src = "transcription (à relire)"
            finally:
                wh.close()
        except Cancelled:
            raise
        except Exception as exc:  # noqa: BLE001
            log(f"Whisper indisponible ou en échec : {exc}")
    if not words_ok and hit and hit.get("syncedLyrics"):
        n = S.times_from_lrc(sheet_lines, S.parse_lrc(hit["syncedLyrics"]))
        log(f"Synchro ligne par ligne (LRCLIB) : {n} lignes")
        words_ok = n > 0
    check()

    # 5. accords dans la partition
    progress("chords", 0.86, "Placement des accords…")
    has_sheet_chords = any(l.chords for l in sheet_lines)
    if has_sheet_chords and words_ok:
        S.chord_times_from_sheet(sheet_lines, detected)
        chords_src = "grille fournie (datée)"
    elif has_sheet_chords:
        chords_src = "grille fournie"
    else:
        beat = 60 / max(an["bpm"], 40)
        sheet_lines = S.place_detected_chords(sheet_lines, detected, beat) if words_ok else (
            sheet_lines + ([S.Line("section", label="Accords détectés", section="instrumental")] if detected else []) +
            [S.Line("chords", "", [[n, c["name"], c["s"]] for n, c in enumerate(detected[k:k + 4])]) for k in range(0, len(detected), 4)])
        chords_src = "détectés dans l'audio (à vérifier)"
    S.mark_chorus(sheet_lines)

    # 6. pack
    progress("pack", 0.92, "Création du pack…")
    pack = work / "pack"
    if pack.exists():
        shutil.rmtree(pack)
    pack.mkdir()
    stem_files: dict[str, str] = {}
    for k, p in stems.items():
        name = f"{STEM_LABELS.get(k, k)}.mp3"
        run_ffmpeg(["-i", str(p), "-codec:a", "libmp3lame", "-b:a", "192k", str(pack / name)])
        stem_files[k] = name
    if not stems:
        name = f"Morceau{src.suffix.lower()}"
        shutil.copy(src, pack / name)
        stem_files["mix"] = name
    meta_out = {"title": title, "artist": artist, "key": meta.get("key") or key_out, "capo": capo or "", "tempo": round(an["bpm"])}
    (pack / f"{safe(title)}.cho").write_text(S.write_chordpro(sheet_lines, meta_out), encoding="utf-8")
    if words_ok:
        (pack / f"{safe(title)}.lrc").write_text(S.write_lrc(sheet_lines, meta_out), encoding="utf-8")
    notes = f"Séparation : {sep_desc or 'aucune'} · paroles : {lyrics_src} · accords : {chords_src}"
    song = {
        "format": "musimix-3",
        "title": title, "artist": artist, "key": meta_out["key"], "capo": capo, "bpm": an["bpm"],
        "duration": round(duration, 2), "lang": lang,
        "beats": an["beats"], "downbeats": an["downbeats"],
        "chordsDetected": detected,
        "peaks": an["peaks"],
        "stems": stem_files,
        "analysis": {"notes": notes, "seconds": round(time.time() - t_start), "studio": "1.0"},
        "lines": S.to_song_lines(sheet_lines),
    }
    (pack / "song.json").write_text(json.dumps(song, ensure_ascii=False), encoding="utf-8")
    out_zip_dir.mkdir(parents=True, exist_ok=True)
    base = f"{safe(artist)} - {safe(title)}" if artist else safe(title)
    zpath = out_zip_dir / f"{base}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:
        for p in sorted(pack.iterdir()):
            z.write(p, p.name)
    log(notes)
    progress("done", 1.0, "Prêt")
    return zpath
