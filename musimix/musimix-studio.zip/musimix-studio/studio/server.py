"""MusiMix Studio — serveur local.

  • reçoit un audio depuis l'appli MusiMix (PC, téléphone, tablette du même Wi-Fi),
  • le prépare en arrière-plan (une file d'attente, un morceau à la fois),
  • renvoie le pack prêt à jouer ;
  • sert aussi l'appli MusiMix elle-même (http://ADRESSE-DU-PC:8765).
"""
from __future__ import annotations

import json
import os
import queue
import shutil
import socket
import sys
import threading
import time
import traceback
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from . import pipeline as P

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("MUSIMIX_DATA", ROOT / "donnees"))
JOBS = DATA / "travaux"
PACKS = DATA / "morceaux-prets"
MODELS = DATA / "modeles"
for d in (JOBS, PACKS, MODELS):
    d.mkdir(parents=True, exist_ok=True)

APP_DIR = next((p for p in [ROOT / "app", ROOT.parent / "musimix"] if (p / "index.html").exists()), None)
HERE = Path(__file__).resolve().parent


def lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return "127.0.0.1"


# ─────────────────────────────────────────────────────── travaux ──
class Job:
    FIELDS = ("id", "title", "artist", "status", "step", "progress", "message", "error", "created", "finished", "pack", "opts", "src", "log")

    def __init__(self, **kw):
        self.id = kw.get("id") or uuid.uuid4().hex[:12]
        self.title = kw.get("title", "")
        self.artist = kw.get("artist", "")
        self.status = kw.get("status", "queued")
        self.step = kw.get("step", "queued")
        self.progress = kw.get("progress", 0.0)
        self.message = kw.get("message", "En attente…")
        self.error = kw.get("error")
        self.created = kw.get("created", time.time())
        self.finished = kw.get("finished")
        self.pack = kw.get("pack")
        self.opts = kw.get("opts", {})
        self.src = kw.get("src")
        self.log = kw.get("log", [])
        self.cancel = False

    @property
    def dir(self) -> Path:
        return JOBS / self.id

    def save(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "job.json").write_text(json.dumps({k: getattr(self, k) for k in self.FIELDS}, ensure_ascii=False), encoding="utf-8")

    def public(self) -> dict:
        return {k: getattr(self, k) for k in ("id", "title", "artist", "status", "step", "progress", "message", "error", "created", "finished")} | {"ready": bool(self.pack)}


class Runner:
    def __init__(self):
        self.jobs: dict[str, Job] = {}
        self.q: "queue.Queue[str]" = queue.Queue()
        for f in sorted(JOBS.glob("*/job.json")):
            try:
                j = Job(**json.loads(f.read_text(encoding="utf-8")))
            except Exception:  # noqa: BLE001
                continue
            if j.status in ("queued", "running"):
                j.status, j.step, j.progress, j.message = "queued", "queued", 0.0, "En attente (reprise)…"
                self.q.put(j.id)
            self.jobs[j.id] = j
        threading.Thread(target=self.loop, daemon=True).start()

    def add(self, job: Job):
        self.jobs[job.id] = job
        job.save()
        self.q.put(job.id)

    def loop(self):
        while True:
            jid = self.q.get()
            job = self.jobs.get(jid)
            if not job or job.status != "queued":
                continue
            job.status = "running"
            job.save()
            print(f"\n▶ Préparation : {job.title or job.src}")

            def progress(step, p, msg, job=job):
                job.step, job.progress, job.message = step, round(p, 3), msg
                job.save()
                print(f"  {int(p * 100):3d} %  {msg}")

            def log(msg, job=job):
                job.log.append(msg)
                job.log = job.log[-60:]
                print(f"        {msg}")

            try:
                z = P.prepare(job.dir / job.src, job.dir / "travail", PACKS, job.opts, progress, log, MODELS, lambda job=job: job.cancel)
                job.pack = str(z)
                job.status, job.finished = "done", time.time()
                shutil.rmtree(job.dir / "travail", ignore_errors=True)
                print(f"✅ Prêt : {z.name}")
            except P.Cancelled:
                job.status, job.error, job.message = "error", "Annulé", "Annulé"
            except Exception as exc:  # noqa: BLE001
                traceback.print_exc()
                job.status, job.error = "error", f"{exc}"
                job.message = f"Échec : {exc}"
            job.save()


runner: Runner | None = None

# ─────────────────────────────────────────────────────── appli web ──
app = FastAPI(title="MusiMix Studio", version=VERSION)


class Cors(BaseHTTPMiddleware):
    """L'appli en ligne (https) et les appareils du réseau local peuvent appeler le Studio."""

    async def dispatch(self, request: Request, call_next):
        origin = request.headers.get("origin", "*")
        if request.method == "OPTIONS":
            resp = JSONResponse({})
        else:
            resp = await call_next(request)
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        resp.headers["Access-Control-Allow-Private-Network"] = "true"
        resp.headers["Access-Control-Expose-Headers"] = "Content-Disposition"
        return resp


app.add_middleware(Cors)


@app.on_event("startup")
def _start():
    global runner
    runner = Runner()


@app.get("/api/health")
def health():
    return {"name": "musimix-studio", "version": VERSION, "device": "GPU" if P.device() == "cuda" else "Processeur",
            "gpu": P.gpu_name(), "address": f"http://{lan_ip()}:{PORT}", "queue": sum(1 for j in runner.jobs.values() if j.status in ("queued", "running"))}


@app.post("/api/jobs")
async def create_job(audio: UploadFile = File(...), title: str = Form(""), artist: str = Form(""), lang: str = Form(""),
                     sheet: str = Form(""), quality: str = Form("best")):
    job = Job(title=title, artist=artist, opts={"title": title, "artist": artist, "lang": lang, "sheet": sheet, "quality": quality})
    job.dir.mkdir(parents=True, exist_ok=True)
    ext = Path(audio.filename or "audio.mp3").suffix.lower() or ".mp3"
    job.src = "source" + ext
    with open(job.dir / job.src, "wb") as f:
        shutil.copyfileobj(audio.file, f)
    if not title:
        job.title, a = P.guess_title_artist(audio.filename or "")
        job.artist = job.artist or a
    runner.add(job)
    return job.public()


@app.get("/api/jobs")
def list_jobs():
    return sorted((j.public() for j in runner.jobs.values()), key=lambda j: -j["created"])


@app.get("/api/jobs/{jid}")
def get_job(jid: str):
    j = runner.jobs.get(jid)
    if not j:
        raise HTTPException(404, "Travail inconnu")
    return j.public() | {"log": j.log[-12:]}


@app.get("/api/jobs/{jid}/pack")
def get_pack(jid: str):
    j = runner.jobs.get(jid)
    if not j or not j.pack or not Path(j.pack).exists():
        raise HTTPException(404, "Pack pas encore prêt")
    return FileResponse(j.pack, media_type="application/zip", filename=Path(j.pack).name)


@app.delete("/api/jobs/{jid}")
def delete_job(jid: str):
    j = runner.jobs.pop(jid, None)
    if j:
        j.cancel = True
        shutil.rmtree(j.dir, ignore_errors=True)
    return {"ok": True}


@app.get("/bridge", response_class=HTMLResponse)
def bridge():
    return (HERE / "bridge.html").read_text(encoding="utf-8")


@app.get("/studio", response_class=HTMLResponse)
def status_page():
    html = (HERE / "status.html").read_text(encoding="utf-8")
    return html.replace("{{ADDRESS}}", f"http://{lan_ip()}:{PORT}").replace("{{VERSION}}", VERSION)


if APP_DIR:
    app.mount("/", StaticFiles(directory=str(APP_DIR), html=True), name="app")
else:
    @app.get("/")
    def root():
        return RedirectResponse("/studio")


PORT = int(os.environ.get("MUSIMIX_PORT", "8765"))


def main():
    import uvicorn
    ip = lan_ip()
    url = f"http://{ip}:{PORT}"
    print("\n" + "─" * 60)
    print("  MusiMix Studio", VERSION)
    print(f"  Sur ce PC          : http://localhost:{PORT}")
    print(f"  Téléphone/tablette : {url}   (même Wi-Fi)")
    print(f"  Calcul             : {'carte graphique ' + (P.gpu_name() or '') if P.device() == 'cuda' else 'processeur (plus lent)'}")
    print("  Laisse cette fenêtre ouverte pendant que tu utilises MusiMix.")
    print("─" * 60)
    try:
        import qrcode  # type: ignore
        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.print_ascii(invert=True)
        print("  Scanne ce code avec ton téléphone pour ouvrir MusiMix.\n")
    except Exception:  # noqa: BLE001
        pass
    if "--no-browser" not in sys.argv:
        threading.Timer(1.5, lambda: __import__("webbrowser").open(f"http://localhost:{PORT}")).start()
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")


if __name__ == "__main__":
    main()
