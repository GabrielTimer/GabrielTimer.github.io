"""MusiMix Studio — partitions : lecture (ChordPro, grilles, paroles), synchro des mots,
placement des accords, écriture des formats MusiMix (song.json musimix-3, .cho, .lrc)."""
from __future__ import annotations

import difflib
import re
import unicodedata
from dataclasses import dataclass, field

NOTE_RE = r"[A-G](?:#|b)?"
CHORD_RE = re.compile(
    rf"^{NOTE_RE}"
    r"(?:maj|min|m|M|dim|aug|sus|add|°|º|ø|Δ|\+|-|\d|\(|\)|#|b|/(?=\d))*"
    rf"(?:/{NOTE_RE})?$"
)
SECTION_WORDS = (r"(intro|introdu[cç][aã]o|verse|couplet|verso|estrofe|pr[eé][- ]?(?:chorus|refr[aã]o|refrain|couplet)|chorus|"
                 r"refrain|refr[aã]o|bridge|pont|ponte|solo|outro|final|fin|interlude|instrumental|riff|coda|tag|parte\s*\d+|"
                 r"primeira parte|segunda parte|terceira parte|break|hook|post[- ]?chorus)")
SECTION_RE = re.compile(rf"^\s*[\[(]?\s*{SECTION_WORDS}[^\])\n]*[\])]?\s*:?\s*", re.I)


def section_kind(label: str) -> str:
    l = norm_token_text(label)
    if re.search(r"pre|pr ", l) and re.search(r"refr|chorus|refrain", l):
        return "prechorus"
    if re.search(r"refr|chorus|refrain|hook", l):
        return "chorus"
    if re.search(r"pont|bridge|ponte", l):
        return "bridge"
    if "intro" in l:
        return "intro"
    if re.search(r"outro|final|fin|coda", l):
        return "outro"
    if re.search(r"solo|instrumental|interlude|riff|break", l):
        return "instrumental"
    return "verse"


def norm_token(t: str) -> str:
    t = unicodedata.normalize("NFKD", t.lower())
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]", "", t)


def norm_token_text(t: str) -> str:
    t = unicodedata.normalize("NFKD", (t or "").lower())
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def normalize_chord(c: str) -> str:
    c = c.strip().strip("|")
    c = c.replace("º", "°").replace("°", "dim").replace("ø", "m7b5")
    c = re.sub(r"7M|7\+(?!\d)|Δ7?", "maj7", c)
    c = re.sub(r"^([A-G][#b]?)M7", r"\1maj7", c)
    c = re.sub(r"^([A-G][#b]?)(-|min)", r"\1m", c)
    return c


def is_chord(tok: str) -> bool:
    tok = tok.strip("|")
    if tok.startswith("(") and tok.endswith(")"):
        tok = tok[1:-1]
    return bool(tok) and bool(CHORD_RE.match(tok))


def is_chord_line(line: str) -> bool:
    toks = [t for t in re.split(r"\s+", line.strip()) if t and t not in {"|", "||", "-", "/", "%"}]
    toks = [t for t in toks if not re.fullmatch(r"\(?x\d+\)?|\d+x", t, re.I)]
    return bool(toks) and all(is_chord(t) for t in toks)


@dataclass
class Line:
    kind: str                                  # lyric | chords | section | blank
    text: str = ""
    chords: list[list] = field(default_factory=list)   # [pos, name, t|None]
    label: str = ""
    section: str = ""                          # verse/chorus/... pour kind == section
    chorus: bool = False
    words: list[dict] = field(default_factory=list)   # [{w, s, e}]


def parse_sheet(text: str) -> tuple[list[Line], dict]:
    meta: dict = {}
    lines: list[Line] = []
    text = (text or "").replace("\r\n", "\n").replace("\t", "    ").replace(" ", " ")
    raw = text.split("\n")
    chordpro = bool(re.search(r"\[[A-G][^\]\s]*\]", text)) or bool(re.search(r"^\s*\{\s*\w+\s*[:}]", text, re.M))
    if chordpro:
        in_chorus = False
        for ln in raw:
            m = re.match(r"^\s*\{\s*([\w_-]+)\s*(?::\s*(.*?))?\s*\}\s*$", ln)
            if m:
                k, v = m.group(1).lower(), (m.group(2) or "").strip()
                if k in ("title", "t"): meta["title"] = v
                elif k in ("artist", "a", "subtitle", "st"): meta["artist"] = v
                elif k == "key": meta["key"] = v
                elif k == "capo": meta["capo"] = int(re.sub(r"\D", "", v) or 0)
                elif k in ("tempo", "bpm"): meta["bpm"] = v
                elif k in ("comment", "c", "ci", "cb"): lines.append(Line("section", label=v, section=section_kind(v)))
                elif k in ("start_of_chorus", "soc"): in_chorus = True; lines.append(Line("section", label=v or "Refrain", section="chorus"))
                elif k in ("end_of_chorus", "eoc"): in_chorus = False
                elif k in ("start_of_verse", "sov"): lines.append(Line("section", label=v or "Couplet", section="verse"))
                elif k in ("start_of_bridge", "sob"): lines.append(Line("section", label=v or "Pont", section="bridge"))
                continue
            if ln.strip().startswith("#"):
                continue
            if not ln.strip():
                lines.append(Line("blank")); continue
            text_only, chords = "", []
            for part in re.split(r"(\[[^\]]*\])", ln):
                if part.startswith("[") and part.endswith("]"):
                    inner = part[1:-1].strip()
                    if is_chord(inner):
                        chords.append([len(text_only), normalize_chord(inner), None])
                    else:
                        text_only += part
                else:
                    text_only += part
            if text_only.strip() and not re.fullmatch(r"[\s|/%.\-–x\d()]*", text_only, re.I):
                lead = len(text_only) - len(text_only.lstrip())
                lines.append(Line("lyric", text_only[lead:].rstrip(), [[max(0, p - lead), n, t] for p, n, t in chords], chorus=in_chorus))
            elif chords:
                lines.append(Line("chords", "", [[i, n, None] for i, (_, n, _) in enumerate(chords)], chorus=in_chorus))
        return tidy(lines), meta

    i = 0
    while i < len(raw):
        ln = raw[i].rstrip()
        if not ln.strip():
            lines.append(Line("blank")); i += 1; continue
        if re.match(r"^\s*[eBGDAE]\|[-\d|hpbr/\\~x ]+", ln):
            i += 1; continue
        mk = re.match(r"^\s*(tom|tono|tonalidade|key)\s*:\s*(\S+)", ln, re.I)
        if mk:
            meta["key"] = mk.group(2); i += 1; continue
        mc = re.match(r"^\s*capo(traste)?\s*:?\s*.*?(\d+)", ln, re.I)
        if mc:
            meta["capo"] = int(mc.group(2)); i += 1; continue
        sec = SECTION_RE.match(ln)
        if sec and (sec.end() == len(ln) or is_chord_line(ln[sec.end():])):
            label = re.sub(r"[\[\]():]", "", ln[: sec.end()]).strip()
            label = label[:1].upper() + label[1:]
            lines.append(Line("section", label=label, section=section_kind(label)))
            rest = ln[sec.end():]
            if not rest.strip():
                i += 1; continue
            ln = " " * sec.end() + rest
        if is_chord_line(ln):
            chords = [(m.start(), normalize_chord(m.group().strip("()|"))) for m in re.finditer(r"\S+", ln) if is_chord(m.group())]
            nxt = raw[i + 1].rstrip() if i + 1 < len(raw) else ""
            if nxt.strip() and not is_chord_line(nxt) and not SECTION_RE.match(nxt) and not re.match(r"^\s*[eBGDAE]\|", nxt):
                lead = len(nxt) - len(nxt.lstrip())
                t = nxt[lead:]
                snapped = []
                for p, c in chords:
                    p = max(0, p - lead)
                    while p < len(t) and t[p] == " ":
                        p += 1
                    if snapped and p <= snapped[-1][0]:
                        p = snapped[-1][0] + 1
                    snapped.append([min(p, len(t) + 1), c, None])
                lines.append(Line("lyric", t, snapped)); i += 2; continue
            lines.append(Line("chords", "", [[k, c, None] for k, (_, c) in enumerate(chords)])); i += 1; continue
        lines.append(Line("lyric", ln.strip())); i += 1
    return tidy(lines), meta


def tidy(lines: list[Line]) -> list[Line]:
    out: list[Line] = []
    for l in lines:
        if l.kind == "blank" and (not out or out[-1].kind == "blank"):
            continue
        out.append(l)
    while out and out[-1].kind == "blank":
        out.pop()
    return out


def plain_lyrics(lines: list[Line]) -> str:
    return "\n".join(l.text for l in lines if l.kind == "lyric")


# ─────────────────────────────────────────────────────── synchro ──
def tokens(text: str) -> list[tuple[str, int, int]]:
    return [(m.group(), m.start(), m.end()) for m in re.finditer(r"\S+", text)]


def assign_times(lines: list[Line], aligned: list[tuple[str, float, float]]) -> int:
    """Pose les mots datés (Whisper) sur les mots des lignes. Retourne le nombre de mots retrouvés."""
    flat: list[dict] = []
    for l in lines:
        l.words = [{"w": w, "s": None, "e": None} for w, _, _ in tokens(l.text)] if l.kind == "lyric" else []
        flat.extend(l.words)
    a_tok = [norm_token(w) for w, _, _ in aligned]
    u_tok = [norm_token(w["w"]) for w in flat]
    sm = difflib.SequenceMatcher(None, u_tok, a_tok, autojunk=False)
    found = 0
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            _, s, e = aligned[blk.b + k]
            flat[blk.a + k]["s"], flat[blk.a + k]["e"] = s, e
            found += 1
    known = [i for i, w in enumerate(flat) if w["s"] is not None]
    if known:
        for i, w in enumerate(flat):
            if w["s"] is None:
                prev = max([k for k in known if k < i], default=None)
                nxt = min([k for k in known if k > i], default=None)
                if prev is not None and nxt is not None:
                    frac = (i - prev) / (nxt - prev)
                    w["s"] = flat[prev]["e"] + frac * (flat[nxt]["s"] - flat[prev]["e"])
                elif prev is not None:
                    w["s"] = flat[prev]["e"] + 0.3 * (i - prev)
                else:
                    w["s"] = max(0.0, flat[nxt]["s"] - 0.3 * (nxt - i))
                w["e"] = w["s"] + 0.25
        for i in range(1, len(flat)):
            if flat[i]["s"] < flat[i - 1]["s"]:
                flat[i]["s"] = flat[i - 1]["s"]
            if flat[i]["e"] < flat[i]["s"]:
                flat[i]["e"] = flat[i]["s"] + 0.1
    return found


def times_from_lrc(lines: list[Line], lrc: list[tuple[float, str]]) -> int:
    """Synchro ligne par ligne (LRCLIB) quand Whisper n'est pas disponible."""
    lyr = [l for l in lines if l.kind == "lyric"]
    a = [norm_token_text(l.text) for l in lyr]
    b = [norm_token_text(t) for _, t in lrc]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    n = 0
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            l = lyr[blk.a + k]
            t0 = lrc[blk.b + k][0]
            t1 = lrc[blk.b + k + 1][0] if blk.b + k + 1 < len(lrc) else t0 + 4
            toks = tokens(l.text)
            step = max(0.12, (t1 - t0) * 0.85 / max(1, len(toks)))
            l.words = [{"w": w, "s": t0 + j * step, "e": t0 + (j + 1) * step, "est": True} for j, (w, _, _) in enumerate(toks)]
            n += 1
    return n


def lines_from_transcript(aligned: list[tuple[str, float, float]]) -> list[Line]:
    out: list[Line] = []
    cur: list[dict] = []

    def flush():
        if cur:
            out.append(Line("lyric", " ".join(w["w"] for w in cur), words=list(cur)))
            cur.clear()

    for w, s, e in aligned:
        if cur:
            gap = s - cur[-1]["e"]
            if gap > 2.5:
                flush(); out.append(Line("blank"))
            elif gap > 0.7 or len(cur) >= 9 or (cur[-1]["w"][-1:] in ".!?," and len(cur) >= 4):
                flush()
        cur.append({"w": w, "s": s, "e": e})
    flush()
    return out


def parse_lrc(text: str) -> list[tuple[float, str]]:
    out = []
    for ln in (text or "").splitlines():
        for m in re.finditer(r"\[(\d+):(\d+(?:\.\d+)?)\]", ln):
            out.append((int(m.group(1)) * 60 + float(m.group(2)), re.sub(r"\[[^\]]*\]|<[^>]*>", "", ln).strip()))
    return sorted([x for x in out if x[1]])


# ─────────────────────────────────────────────────────── accords ──
def chord_times_from_sheet(lines: list[Line], detected: list[dict]) -> None:
    """Accords d'une grille fournie : datés par les mots ; lignes d'accords seuls
    calées sur la détection audio quand c'est possible, sinon réparties."""
    for l in lines:
        if l.kind != "lyric" or not l.words or l.words[0]["s"] is None:
            continue
        offs = [st for _, st, _ in tokens(l.text)]
        for c in l.chords:
            p = c[0]
            k = max([j for j, o in enumerate(offs) if o <= p] or [0])
            if k >= len(l.words):
                continue
            w = l.words[k]
            wlen = len(w["w"]) or 1
            if p >= offs[k] + wlen:
                c[2] = w["e"] + 0.1
            else:
                c[2] = w["s"] + (p - offs[k]) / wlen * (w["e"] - w["s"])
    # trous (intro, ponts instrumentaux)
    seq = [(l, c) for l in lines for c in l.chords]
    i = 0
    while i < len(seq):
        if seq[i][1][2] is not None:
            i += 1; continue
        j = i
        while j < len(seq) and seq[j][1][2] is None:
            j += 1
        t0 = seq[i - 1][1][2] + 0.5 if i > 0 else 0.0
        t1 = seq[j][1][2] if j < len(seq) else (detected[-1]["e"] if detected else t0 + 2 * (j - i))
        cands = [d for d in detected if t0 - 0.3 <= d["s"] < t1 - 0.3]
        if len(cands) >= j - i and cands:
            # on prend les changements détectés les plus proches d'une répartition régulière
            step = (t1 - t0) / (j - i)
            used = set()
            for k in range(i, j):
                target = t0 + (k - i) * step
                best = min((d for d in cands if id(d) not in used), key=lambda d: abs(d["s"] - target), default=None)
                if best:
                    used.add(id(best))
                    seq[k][1][2] = best["s"]
            ts = sorted(seq[k][1][2] for k in range(i, j))
            for k, t in zip(range(i, j), ts):
                seq[k][1][2] = t
        else:
            step = max((t1 - t0) / (j - i), 0.4)
            for k in range(i, j):
                seq[k][1][2] = t0 + (k - i) * step
        i = j


def place_detected_chords(lines: list[Line], detected: list[dict], beat: float) -> list[Line]:
    """Accords détectés (datés) → insérés dans les paroles datées + lignes d'accords dans les trous."""
    timed = [i for i, l in enumerate(lines) if l.kind == "lyric" and l.words and l.words[0]["s"] is not None]
    if not timed:
        out = list(lines)
        if detected:
            out.append(Line("section", label="Accords détectés", section="instrumental"))
            for k in range(0, len(detected), 4):
                out.append(Line("chords", "", [[n, c["name"], c["s"]] for n, c in enumerate(detected[k:k + 4])]))
        return out
    out: list[Line] = []
    ci = 0

    def chord_at(t):
        cur = None
        for c in detected:
            if c["s"] <= t + 1e-3:
                cur = c
            else:
                break
        return cur

    def gap(t0, t1, label=None):
        nonlocal ci
        grp = []
        while ci < len(detected) and detected[ci]["s"] < t1 - 0.25:
            if detected[ci]["s"] >= t0 - 0.05:
                grp.append(detected[ci])
            ci += 1
        nxt = chord_at(t1 + 0.25)
        if len(grp) == 1 and nxt and grp[0]["name"] == nxt["name"]:
            return
        if not grp:
            return
        if t1 - t0 < max(3 * beat, 2.5) and out and out[-1].kind == "lyric":
            ln = out[-1]
            for c in grp:
                ln.chords.append([len(ln.text) + 1 + len(ln.chords), c["name"], c["s"]])
            return
        if label:
            out.append(Line("section", label=label, section=section_kind(label)))
        for k in range(0, len(grp), 4):
            out.append(Line("chords", "", [[n, c["name"], c["s"]] for n, c in enumerate(grp[k:k + 4])]))

    def last_shown():
        for ln in reversed(out):
            if ln.chords:
                return sorted(ln.chords, key=lambda x: x[0])[-1][1]
            if ln.kind == "section":
                return None
        return None

    first = timed[0]
    last_end = 0.0
    for idx, ln in enumerate(lines):
        if ln.kind != "lyric" or not ln.words or ln.words[0]["s"] is None:
            out.append(ln)
            continue
        start, end = ln.words[0]["s"], ln.words[-1]["e"]
        gap(last_end, start - 0.25, "Intro" if idx == first else None)
        new = Line("lyric", ln.text, [], chorus=ln.chorus, words=ln.words)
        offs = [st for _, st, _ in tokens(ln.text)]
        cur = chord_at(start)
        if cur and cur["name"] != last_shown():
            new.chords.append([0, cur["name"], min(cur["s"], start) if cur["s"] > start - 4 else start])
        while ci < len(detected) and detected[ci]["s"] < start - 0.25:
            ci += 1
        while ci < len(detected) and detected[ci]["s"] < end:
            c = detected[ci]
            k = min(range(len(ln.words)), key=lambda j: abs(ln.words[j]["s"] - c["s"]))
            p = offs[k] if k < len(offs) else 0
            if not new.chords or new.chords[-1][1] != c["name"]:
                new.chords = [x for x in new.chords if x[0] != p] + [[p, c["name"], c["s"]]]
            ci += 1
        out.append(new)
        last_end = end
    gap(last_end, 1e9, "Fin")
    return out


def mark_chorus(lines: list[Line]) -> None:
    if any(l.kind == "section" and l.section == "chorus" for l in lines):
        inside = False
        for l in lines:
            if l.kind == "section":
                inside = l.section == "chorus"
            elif inside and l.kind in ("lyric", "chords"):
                l.chorus = True
        return
    stanzas, cur = [], []
    for i, l in enumerate(lines):
        if l.kind == "lyric":
            cur.append(i)
        elif l.kind in ("blank", "section") and cur:
            stanzas.append(cur); cur = []
    if cur:
        stanzas.append(cur)
    sig = ["|".join(norm_token_text(lines[i].text) for i in s) for s in stanzas]
    counts: dict[str, int] = {}
    for k, s in enumerate(stanzas):
        if len(s) >= 2:
            counts[sig[k]] = counts.get(sig[k], 0) + 1
    for k, s in enumerate(stanzas):
        if counts.get(sig[k], 0) >= 2:
            for i in s:
                lines[i].chorus = True


def transpose_name(name: str, n: int, flats: bool) -> str:
    names = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"] if flats else ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    pcs = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}

    def tr(note: str) -> str:
        pc = pcs[note[0]] + (1 if note[1:] == "#" else -1 if note[1:] == "b" else 0)
        return names[(pc + n) % 12]

    m = re.match(r"^([A-G][#b]?)([^/]*)(?:/([A-G][#b]?))?$", name)
    if not m or not n:
        return name
    return tr(m.group(1)) + m.group(2) + ("/" + tr(m.group(3)) if m.group(3) else "")


# ─────────────────────────────────────────────────────── écriture ──
def r3(x):
    return None if x is None else round(float(x), 3)


def to_song_lines(lines: list[Line]) -> list[dict]:
    out = []
    for l in lines:
        if l.kind == "section":
            out.append({"type": "section", "label": l.label, "kind": l.section or section_kind(l.label)})
        elif l.kind == "blank":
            out.append({"type": "blank"})
        elif l.kind == "chords":
            d = {"type": "chords", "chords": [{"pos": p, "name": n, **({"t": r3(t)} if t is not None else {})} for p, n, t in l.chords]}
            if l.chorus:
                d["chorus"] = True
            out.append(d)
        else:
            d = {"type": "lyric", "text": l.text}
            if l.chords:
                d["chords"] = [{"pos": p, "name": n, **({"t": r3(t)} if t is not None else {})} for p, n, t in l.chords]
            if l.chorus:
                d["chorus"] = True
            if l.words and l.words[0].get("s") is not None:
                d["s"] = r3(l.words[0]["s"])
                d["e"] = r3(l.words[-1]["e"])
                if not all(w.get("est") for w in l.words):
                    d["words"] = [{"s": r3(w["s"]), "e": r3(w["e"])} for w in l.words]
            out.append(d)
    return out


def chordpro_line(text: str, chords: list) -> str:
    text = text.rstrip()
    inside = sorted([c for c in chords if c[0] < len(text)], key=lambda x: x[0])
    after = [c for c in sorted(chords, key=lambda x: x[0]) if c[0] >= len(text)]
    res, last = "", 0
    for p, c, _ in inside:
        res += text[last:p] + f"[{c}]"
        last = p
    res += text[last:]
    for _, c, _ in after:
        res += f" [{c}]"
    return res


def write_chordpro(lines: list[Line], meta: dict) -> str:
    out = [f"{{title: {meta.get('title', '')}}}", f"{{artist: {meta.get('artist', '')}}}"]
    for k in ("key", "capo", "tempo"):
        if meta.get(k):
            out.append(f"{{{k}: {meta[k]}}}")
    out.append("")
    for l in lines:
        if l.kind == "blank":
            if out[-1] != "":
                out.append("")
        elif l.kind == "section":
            if out[-1] != "":
                out.append("")
            out.append(f"{{comment: {l.label}}}")
        elif l.kind == "chords":
            out.append(" ".join(f"[{c[1]}]" for c in l.chords))
        else:
            out.append(chordpro_line(l.text, l.chords))
    return "\n".join(out).rstrip() + "\n"


def fmt_ts(t: float) -> str:
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def write_lrc(lines: list[Line], meta: dict) -> str:
    out = [f"[ti:{meta.get('title', '')}]", f"[ar:{meta.get('artist', '')}]"]
    for l in lines:
        if l.kind == "lyric" and l.words and l.words[0].get("s") is not None:
            if all(w.get("est") for w in l.words):
                out.append(f"[{fmt_ts(l.words[0]['s'])}]{l.text.strip()}")
            else:
                out.append(f"[{fmt_ts(l.words[0]['s'])}]" + " ".join(f"<{fmt_ts(w['s'])}>{w['w']}" for w in l.words))
    return "\n".join(out) + "\n"
