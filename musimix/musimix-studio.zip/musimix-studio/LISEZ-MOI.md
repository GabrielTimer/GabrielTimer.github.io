# MusiMix Studio

Le programme qui prépare tes morceaux pour MusiMix, sur ton PC Windows.
Tu glisses un mp3 dans MusiMix, le Studio s'occupe du reste :

1. **Voix** isolée avec le modèle BS-Roformer (le même moteur qu'Ultimate Vocal Remover).
2. **Instruments** séparés avec Demucs : batterie, basse, guitare, piano, autres.
3. **Paroles** cherchées sur LRCLIB (ou celles que tu colles), puis **synchronisées mot à mot** par Whisper sur la voix isolée. Sans paroles trouvées : transcription automatique, à relire.
4. **Accords**, **tempo** et **mesures** détectés dans l'audio. Si tu colles une grille (Cifra Club, Ultimate Guitar…), ce sont ses accords qui sont utilisés, calés sur les mots.
5. Le morceau arrive tout seul dans la bibliothèque de MusiMix.

## Installer (une seule fois)

1. Décompresse ce dossier, par exemple dans `Documents\musimix-studio`.
2. Double-clic sur **Installer.bat**.
   Compte 10 à 20 minutes et environ 6 Go : Python, PyTorch pour ta carte NVIDIA, les modèles d'IA.
   Windows peut demander une confirmation (SmartScreen) : « Informations complémentaires » → « Exécuter quand même ».

## Utiliser

- Double-clic sur **MusiMix Studio.bat**. Une fenêtre noire s'ouvre : laisse-la ouverte.
  Elle affiche l'adresse à utiliser sur le téléphone et un QR code.
- Au premier lancement, Windows demande d'autoriser Python sur le réseau : coche **Réseaux privés** et accepte (sinon le téléphone ne pourra pas joindre le Studio).
- **Sur le PC** : MusiMix s'ouvre dans le navigateur, déjà connecté au Studio.
- **Sur le téléphone ou la tablette** (même Wi-Fi) :
  - soit tu ouvres MusiMix comme d'habitude, puis Réglages → Studio → adresse affichée par le Studio (ex. `192.168.1.20`). Au moment de préparer un morceau, une petite fenêtre du Studio s'ouvre : laisse-la ouverte ;
  - soit tu scannes le QR code : l'appli s'ouvre directement depuis le PC.
- **Lancer au demarrage de Windows.bat** : le Studio démarre tout seul avec Windows (fenêtre réduite). Relance-le pour annuler.

## Temps de préparation (Quadro P2000)

| Étape | Durée approximative |
|---|---|
| Voix (Roformer) | 1 à 3 min |
| Instruments (Demucs 6 pistes) | 1 à 2 min |
| Paroles (Whisper medium) | 1 à 2 min |
| Accords, tempo, pack | 15 s |
| **Total** | **environ 3 à 7 min** |

Sans carte graphique utilisable, tout passe sur le processeur : 10 à 20 minutes par morceau.

## Où sont les fichiers

- `donnees\morceaux-prets\` : les packs ZIP prêts (aussi téléchargeables sur `http://localhost:8765/studio`).
- `donnees\modeles\` : les modèles d'IA.
- `donnees\travaux\` : les travaux en cours (supprimables).

## Réglages avancés (variables d'environnement)

| Variable | Effet |
|---|---|
| `MUSIMIX_WHISPER=small` | Whisper plus léger (plus rapide, moins précis) ; `large-v3` demande plus de 6 Go de mémoire graphique |
| `MUSIMIX_CPU=1` | force le calcul sur le processeur |
| `MUSIMIX_PORT=8765` | port du serveur |
| `MUSIMIX_VOCAL_MODEL=…` | autre modèle de voix d'Ultimate Vocal Remover (nom de fichier) |

## En cas de souci

- **« Le Studio ne répond pas »** : la fenêtre du Studio est-elle ouverte ? Sur téléphone, même Wi-Fi que le PC, et pare-feu autorisé (voir plus haut).
- **Erreur de mémoire graphique** : relance le Studio ; il bascule automatiquement sur des modèles plus légers. Sinon `MUSIMIX_WHISPER=small`.
- **Accords approximatifs** : la détection automatique donne une bonne base (souvent 70 à 85 % juste). Pour un résultat parfait, colle la grille d'accords au moment de l'import, ou corrige dans MusiMix → Éditer.
