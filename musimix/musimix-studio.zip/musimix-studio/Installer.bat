@echo off
chcp 65001 >nul
title Installation de MusiMix Studio
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo.
echo  ==================================================
echo    Installation de MusiMix Studio (une seule fois)
echo    Compte 10 à 20 minutes et environ 6 Go.
echo  ==================================================
echo.
where uv >nul 2>nul
if errorlevel 1 (
  echo [1/4] Installation de l'outil uv...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
)
set "PATH=%USERPROFILE%\.local\bin;%PATH%"
where uv >nul 2>nul
if errorlevel 1 goto :err
echo [2/4] Python 3.11...
uv venv .venv --python 3.11 --allow-existing
if errorlevel 1 goto :err
echo [3/4] PyTorch pour carte graphique NVIDIA (gros téléchargement)...
uv pip install --python .venv\Scripts\python.exe torch==2.7.1 torchaudio==2.7.1 --index-url https://download.pytorch.org/whl/cu126
if errorlevel 1 goto :err
echo [3/4] Séparation, Whisper, serveur...
uv pip install --python .venv\Scripts\python.exe -r requirements.txt -c constraints.txt --extra-index-url https://download.pytorch.org/whl/cu126 --index-strategy unsafe-best-match
if errorlevel 1 goto :err
echo [4/4] Téléchargement des modèles d'IA...
.venv\Scripts\python.exe -m studio.setup
if errorlevel 1 goto :err
echo.
echo  Installation terminée. Lance maintenant "MusiMix Studio.bat".
echo.
pause
exit /b 0
:err
echo.
echo  Une étape a échoué. Vérifie la connexion Internet puis relance Installer.bat.
echo  Le message d'erreur est juste au-dessus.
pause
exit /b 1
