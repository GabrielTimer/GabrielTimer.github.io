@echo off
chcp 65001 >nul
title MusiMix Studio
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
if not exist .venv\Scripts\python.exe (
  echo MusiMix Studio n'est pas encore installé : double-clique d'abord sur Installer.bat
  pause
  exit /b 1
)
set "PATH=%~dp0.venv\Scripts;%PATH%"
.venv\Scripts\python.exe -m studio.server %*
pause
