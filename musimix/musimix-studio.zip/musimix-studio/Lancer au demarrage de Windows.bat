@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "TARGET=%~dp0MusiMix Studio.bat"
set "WORKDIR=%~dp0"
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MusiMix Studio.lnk"
if exist "%LNK%" (
  del "%LNK%"
  echo MusiMix Studio ne se lancera plus au démarrage de Windows.
) else (
  powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK); $s.TargetPath=$env:TARGET; $s.Arguments='--no-browser'; $s.WorkingDirectory=$env:WORKDIR; $s.WindowStyle=7; $s.Save()"
  echo MusiMix Studio se lancera automatiquement au démarrage de Windows, fenêtre réduite.
  echo Relance ce fichier pour annuler.
)
pause
